package com.example.intents;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
public class MainActivity4 extends AppCompatActivity {
    private DatabaseReference mDatabase;
    EditText Email,pass;
    TextView gotoLogin;

    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        EditText t1=(EditText)findViewById(R.id.editTextTextPersonName);
        EditText t2=(EditText)findViewById(R.id.editTextTextPassword);
        EditText t3=(EditText) findViewById(R.id.editTextTextEmailAddress);
        EditText t4=(EditText)findViewById(R.id.editTextNumber);
        gotoLogin = findViewById(R.id.gotologin);
        gotoLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),MainActivity7.class);
                startActivity(intent);
            }
        });
        mAuth = FirebaseAuth.getInstance();
        Email = findViewById(R.id.editTextTextEmailAddress);
        pass = findViewById(R.id.editTextTextPassword);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button b=(Button)findViewById(R.id.Register);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1=t1.getText().toString();
                String s2=t2.getText().toString();
                String s3=t3.getText().toString();
                String s4=t4.getText().toString();
                System.out.println(s1+"\n");
                System.out.println(s2+"\n");
                System.out.println(s3+"\n");
                writeNewUser(s1,s2,s3);
                createAccount();
            }
        });
        mDatabase = FirebaseDatabase.getInstance().getReference();
    }
    public void writeNewUser(String username, String password, String email) {
        User user = new User(username,password,email);
        mDatabase.child("EMP").child(username).setValue(user);
    }
    private void createAccount() {
        String email = Email.getText().toString();
        String password = pass.getText().toString();
        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(MainActivity4.this,"email and password Registered",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(MainActivity4.this,"Registration failed",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}