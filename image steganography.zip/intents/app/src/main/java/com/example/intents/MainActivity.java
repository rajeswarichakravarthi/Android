package com.example.intents;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.NonNull;
import android.os.Message;
import android.view.MenuItem;
import android.app.ProgressDialog;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.PopupMenu;
import android.widget.TextView;
import java.text.BreakIterator;
public class MainActivity extends AppCompatActivity {
    ProgressDialog   pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b1=findViewById(R.id.exp);
        ImageButton leftIcon = findViewById(R.id.menu);
        ImageButton sea=findViewById(R.id.more);
        b1.setOnClickListener(new View.OnClickListener() {
            Handler handler=new Handler(){
                @Override
                public void handleMessage(@NonNull Message msg) {
                    super.handleMessage(msg);
                    pd.incrementProgressBy(2);
                }
            };
            @Override
            public void onClick(View view){
                pd=new ProgressDialog(MainActivity.this);
                pd.setMessage("Loading…");
                pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                pd.show();
                pd.setCancelable(false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            while(pd.getProgress()<=pd.getMax())
                            {
                                Thread.sleep(200);
                                handler.sendMessage(handler.obtainMessage());
                                if(pd.getProgress()==pd.getMax())
                                {
                                    pd.dismiss();
                                }
                            }
                        }catch (InterruptedException e){
                            e.printStackTrace();
                        }
                    }
                }).start();
                Intent i=new Intent(getApplicationContext(),MainActivity2.class);
                startActivity(i);
            }
        });

        Button b2=findViewById(R.id.imp);
        b2.setOnClickListener(new View.OnClickListener() {
            Handler handler=new Handler(){
                @Override
                public void handleMessage(@NonNull Message msg) {
                    super.handleMessage(msg);
                    pd.incrementProgressBy(2);
                }
            };
            @Override
            public void onClick(View view) {
                pd=new ProgressDialog(MainActivity.this);
                pd.setMessage("Loading…");
                pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                pd.show();
                pd.setCancelable(false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            while(pd.getProgress()<=pd.getMax())
                            {
                                Thread.sleep(200);
                                handler.sendMessage(handler.obtainMessage());
                                if(pd.getProgress()==pd.getMax())
                                {
                                    pd.dismiss();
                                }
                            }
                        }catch (InterruptedException e){
                            e.printStackTrace();
                        }
                    }
                }).start();
                Intent i=new Intent(getApplicationContext(),MainActivity3.class);
                startActivity(i);
            }
        });
        leftIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Menu", Toast.LENGTH_SHORT).show();
                PopupMenu popupMenu = new PopupMenu(MainActivity.this, leftIcon);
                popupMenu.getMenuInflater().inflate(R.menu.menu1, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        Toast.makeText(MainActivity.this,"you have selected "+menuItem, Toast.LENGTH_SHORT).show();
                        switch (menuItem.getItemId()) {
                            case R.id.reg:
                                Intent intent1 = new Intent(MainActivity.this, MainActivity4.class);
                                startActivity(intent1);
                                return true;
                            case R.id.log:
                                Intent intent2 = new Intent(MainActivity.this, MainActivity7.class);
                                startActivity(intent2);
                                return true;
                        }
                        return true;
                    }
                });
                popupMenu.show();
            }
        });
        sea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "About", Toast.LENGTH_SHORT).show();
                Intent inti=new Intent(MainActivity.this,MainActivity8.class);
                startActivity(inti);
            }
        });
    }

}
