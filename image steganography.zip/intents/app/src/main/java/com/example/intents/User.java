package com.example.intents;

import com.google.firebase.database.DataSnapshot;

public class User {
    public String username;
    public String email;
    public String password;

    public User() {
        //DataSnapshot.getValue(User.class);
    }
    public User(String username, String password, String email) {
        this.username = username;
        this.email = email;
        this.password=password;
    }
    public String getEmail() {
        return email;
    }
    public String getPassword() {
        return password;
    }
    public String getUsername() {
        return username;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setUsername(String username) {
        this.username = username;
    }

}
